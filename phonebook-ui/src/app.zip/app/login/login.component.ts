import {Component, Input, OnInit} from '@angular/core';
import {HttpErrorResponse} from "@angular/common/http";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {UserService} from "../service/user.service";
import {AuthenticationService} from "../service/authentication.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email = '';
  password = '';
  invalidLogin = false;

  @Input() error: string | null;

  constructor(private router: Router,
              private loginservice: AuthenticationService) { }

  ngOnInit() {}

  checkLogin() {
    (this.loginservice.authenticate(this.email, this.password).subscribe(
        data => {
          //console.log(data);
          this.router.navigate(['']);
          this.invalidLogin = false;

        },
        error => {
          this.invalidLogin = true;
          // this.error = error.message;
          this.error = error.status;

        }
      )
    );

  }

  }

