export interface User {
  password: string
  email: string
}
