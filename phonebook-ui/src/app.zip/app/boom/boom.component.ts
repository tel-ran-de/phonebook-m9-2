import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";


@Component({
  selector: 'app-boom',
  templateUrl: './boom.component.html',
  styleUrls: ['./boom.component.css']
})
export class BoomComponent{

  userName : string="";
  response :any;

  constructor(public http: HttpClient) { }


/*  search(){
    this.http.get<any>('/api/user')
      .subscribe((response)=>{
        this.response = response;
        console.log(this.response);
      })
  }*/

  search(){
    this.http.get<any>('/api/user')
      .subscribe((data: any[])=>{
        console.log(data);
      })
  }

}
