import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';

// @ts-ignore
@Injectable({
  providedIn: 'root'
})
export class BasicAuthHtppInterceptorService implements HttpInterceptor {

  constructor() { }

  intercept(req: HttpRequest<any>, next: HttpHandler) {

    if (localStorage.getItem('email') && localStorage.getItem('access-token')) {
      req = req.clone({
        setHeaders: {
          Token: localStorage.getItem('access-token')
        }
      })
    }

    return next.handle(req);

  }
}
